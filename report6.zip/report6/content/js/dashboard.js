/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 65.82971908042067, "KoPercent": 34.17028091957933};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.470281628256371, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.3981160371168807, 500, 1500, "Get characters"], "isController": false}, {"data": [0.4417939888335395, 500, 1500, "Get character/id"], "isController": false}, {"data": [0.5151349723278491, 500, 1500, "Put character/id"], "isController": false}, {"data": [0.5492143123678428, 500, 1500, "Delete character/id"], "isController": false}, {"data": [0.47262364082777975, 500, 1500, "Post character"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 141108, 48217, 34.17028091957933, 10195.892040139253, 1, 214657, 146.0, 469.0, 10252.95, 60289.96000000001, 405.8933173784978, 4394.4460822486035, 49.602500117755596], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Get characters", 32007, 12969, 40.51926141156622, 11275.455650326501, 1, 199257, 514.0, 55984.80000000002, 119991.75, 128450.17000000045, 92.0683227669685, 4083.5106729153963, 6.7677834131324], "isController": false}, {"data": ["Get character/id", 29911, 11623, 38.85861388786734, 10205.14436160603, 2, 214657, 507.0, 42808.600000000006, 63592.85000000009, 124943.94, 86.19387931531324, 98.29610077409083, 6.536408992096997], "isController": false}, {"data": ["Put character/id", 26561, 7906, 29.765445578103233, 9953.844584164712, 2, 211990, 470.0, 46003.90000000009, 60086.9, 121945.96, 76.61200767244983, 71.78497580726575, 12.774117469966397], "isController": false}, {"data": ["Delete character/id", 24119, 6045, 25.06322816037149, 8464.184792072643, 2, 172424, 518.0, 33298.70000000005, 56228.9, 120199.99, 69.60288350268236, 56.6889031581237, 10.84930351845332], "isController": false}, {"data": ["Post character", 28510, 9674, 33.93195370045598, 10664.70056120651, 2, 213440, 485.0, 49447.0, 73524.0, 123504.97, 82.18246178414637, 84.95029952747247, 12.783999804704953], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["The operation lasted too long: It took 181,122 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 182,869 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 186,782 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 199,257 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 189,137 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 183,595 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 184,709 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 189,370 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 191,277 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 181,404 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 180,013 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 184,951 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 185,562 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 180,029 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 182,871 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 186,577 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 182,089 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 183,182 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 186,708 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 181,642 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 183,611 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 186,468 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 187,463 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 185,151 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 180,243 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 181,473 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 181,527 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 183,536 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 188,194 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 180,239 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 182,710 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 186,747 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 181,341 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 182,866 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 182,900 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 197,199 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 182,145 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 182,729 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 198,849 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 184,423 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 180,302 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 193,236 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 181,016 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 186,098 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 183,912 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 183,928 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 181,017 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 183,454 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 190,723 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:3001 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Connection refused: connect", 44165, 91.59632494763258, 31.298721546616775], "isController": false}, {"data": ["The operation lasted too long: It took 190,746 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 183,831 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 190,751 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 192,398 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 184,878 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 187,099 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 193,647 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 183,863 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 182,405 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 183,413 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 182,754 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 194,848 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 186,460 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 189,603 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 182,700 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 181,031 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 196,856 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 181,117 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 190,749 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 184,441 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 186,574 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 190,708 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 189,405 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 193,335 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 185,979 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 184,540 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 184,432 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 188,955 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 190,757 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 189,406 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 2, 0.004147914635916793, 0.0014173540833971143], "isController": false}, {"data": ["The operation lasted too long: It took 182,905 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["The operation lasted too long: It took 181,274 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["Non HTTP response code: java.net.BindException/Non HTTP response message: Address already in use: connect", 2174, 4.508783209241554, 1.5406638886526631], "isController": false}, {"data": ["The operation lasted too long: It took 183,088 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:3001 failed to respond", 1794, 3.720679428417363, 1.2713666128072114], "isController": false}, {"data": ["The operation lasted too long: It took 190,706 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, 0.0020739573179583966, 7.086770416985572E-4], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 141108, 48217, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:3001 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Connection refused: connect", 44165, "Non HTTP response code: java.net.BindException/Non HTTP response message: Address already in use: connect", 2174, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:3001 failed to respond", 1794, "The operation lasted too long: It took 189,406 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 2, "The operation lasted too long: It took 181,122 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["Get characters", 32007, 12969, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:3001 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Connection refused: connect", 12224, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:3001 failed to respond", 386, "Non HTTP response code: java.net.BindException/Non HTTP response message: Address already in use: connect", 276, "The operation lasted too long: It took 189,406 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 2, "The operation lasted too long: It took 181,122 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1], "isController": false}, {"data": ["Get character/id", 29911, 11623, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:3001 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Connection refused: connect", 10837, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:3001 failed to respond", 467, "Non HTTP response code: java.net.BindException/Non HTTP response message: Address already in use: connect", 318, "The operation lasted too long: It took 181,341 milliseconds, but should not have lasted longer than 180,000 milliseconds.", 1, "", ""], "isController": false}, {"data": ["Put character/id", 26561, 7906, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:3001 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Connection refused: connect", 6997, "Non HTTP response code: java.net.BindException/Non HTTP response message: Address already in use: connect", 576, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:3001 failed to respond", 333, "", "", "", ""], "isController": false}, {"data": ["Delete character/id", 24119, 6045, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:3001 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Connection refused: connect", 5356, "Non HTTP response code: java.net.BindException/Non HTTP response message: Address already in use: connect", 349, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:3001 failed to respond", 340, "", "", "", ""], "isController": false}, {"data": ["Post character", 28510, 9674, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to localhost:3001 [localhost/127.0.0.1, localhost/0:0:0:0:0:0:0:1] failed: Connection refused: connect", 8751, "Non HTTP response code: java.net.BindException/Non HTTP response message: Address already in use: connect", 655, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: localhost:3001 failed to respond", 268, "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
